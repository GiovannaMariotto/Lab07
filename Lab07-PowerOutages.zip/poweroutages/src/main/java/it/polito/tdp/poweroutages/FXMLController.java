/**
 * Sample Skeleton for 'Scene.fxml' Controller Class
 */

package it.polito.tdp.poweroutages;

import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.IllegalFormatException;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import it.polito.tdp.poweroutages.model.Event;
import it.polito.tdp.poweroutages.model.Model;
import it.polito.tdp.poweroutages.model.Nerc;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class FXMLController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML
    private Button btnWorstCase;
    
    @FXML // fx:id="cmbNerc"
    private ComboBox<Nerc> cmbNerc; // Value injected by FXMLLoader

    @FXML // fx:id="txtYears"
    private TextField txtYears; // Value injected by FXMLLoader

    @FXML // fx:id="txtHours"
    private TextField txtHours; // Value injected by FXMLLoader

    @FXML // fx:id="txtResult"
    private TextArea txtResult; // Value injected by FXMLLoader

    private Model model;
    private final String NO_RESULT_FOUND_ERROR = "There are no power outages matching this criteria!";
    
    public LinkedHashMap<String,Nerc> getMapNerc(List<Nerc> nercs){
    	LinkedHashMap<String,Nerc> mapN = new LinkedHashMap<String, Nerc>();
    	for(Nerc n : nercs) {
    		mapN.put(n.getValue(), n);
    	}
    	
    	return mapN;
    }
    
    
    @FXML
    void doRun(ActionEvent event) {
    	txtResult.clear();
    	txtResult.setDisable(true);
    	Map<String,Nerc>mapaNerc = this.getMapNerc(this.model.getNercList());
    	Nerc selectedNerc = null;
    	String maxHoursInput = null;
    	String maxYearsInput = null;
    	try {
    	 selectedNerc = this.cmbNerc.getSelectionModel().getSelectedItem();
    	 maxHoursInput = this.txtHours.getText();
    	 maxYearsInput = this.txtYears.getText();
    	}catch(Exception e) {
    		e.getStackTrace();
    		this.txtResult.setText("Error in getting the input -1");	
    	}
    	
    	if(mapaNerc.containsKey(selectedNerc.getValue())) {
    		selectedNerc=mapaNerc.get(selectedNerc.getValue());
    		selectedNerc.setEventi(this.model.getAllEventi(selectedNerc));
    	} else {
    		for(Nerc n : this.model.getNercList()) {
    			if(n!=null && n.getValue().equals(selectedNerc.getValue())) {
    				selectedNerc=n;
    				mapaNerc.put(n.getValue(), n);
    				selectedNerc.setEventi(this.model.getAllEventi(selectedNerc));
    			}
    		}
    		
    	}
    	
    	
    	if(selectedNerc==null || maxHoursInput==null || maxYearsInput==null) {
    		this.txtResult.setText("Error in getting the input -2");
    		
    	}
    	int maxHours,maxYears;
    	
    	try {
    		maxYears = Integer.parseInt(maxYearsInput);
    		maxHours = Integer.parseInt(maxHoursInput);
    	} catch(NumberFormatException e) {
    		e.printStackTrace();
    		this.txtResult.setText("Wrong input format exception");
    		return;
    	}
    	
    	if(maxYears<=0) {
    		this.txtResult.setText("Select a number of years greater than zero");
    		return;
    	}
    	if(maxHours<=0) {
    		this.txtResult.setText("Select a number of hours greater than zero");
    		return;
    	}
    	
    	txtResult.setDisable(false);
    	long init = System.currentTimeMillis();
    	List<Event> worstCasePO = this.model.computeWorstCase(maxHours, maxYears, selectedNerc);
    	long fin = System.currentTimeMillis();
    	
    	if(worstCasePO.isEmpty()) {
    		this.txtResult.appendText("NO_RESULT_FOUND_ERROR");
    		return;
    	}
    	
    	
    	this.txtResult.setText(String.format("Calculating worst case analysis... for %d hours %d days \n", maxHours,maxYears));
    	int totPeopleAffected = this.model.totCostumersAffected(worstCasePO);
    	long totalHoursOfOutage = this.model.totHoursAffected(worstCasePO);
    	
    	
    	
    	this.txtResult.appendText("Total costumers affected: "+totPeopleAffected+"\n");
    	this.txtResult.appendText("Total Hours of Outage: "+totalHoursOfOutage+"\n");
    	for(Event e : worstCasePO) {
    		if(e!=null) {
    			this.txtResult.appendText(e.toString()+"\n");
    		}
    	}
    	
    	
    	
    	
    /*	StringBuilder output = new StringBuilder();
    	output.append("time: ").append(fin-init).append("ms\n");
    	output.append("Total people affected:").append(totPeopleAffected).append("\n");
    	output.append("Total of hours of outage:").append(totalHoursOfOutage).append("\n\n");
    	output.append(String.format("   %-5s %-5s %-20s %-20s %-4s %-4s %-8s\n",
				"id", "year", "event begin", "event finished", "hs", "min", "people"));
    	output.append(this.printPowerOutages(worstCasePO));

    	this.txtResult.setText(output.toString());
    	*/
    	
    }

  
    
    @FXML
    void handleNercSelected(ActionEvent event) {
    	Nerc selectedNerc = this.cmbNerc.getValue();
    	if(!(selectedNerc==null)) {
    		this.txtHours.setDisable(false);
    		this.txtYears.setDisable(false);
    	}else {
    		this.txtHours.setDisable(true);
    		this.txtYears.setDisable(true);
    	}
    	this.checkEmptyFields();
    }
    


	private void checkEmptyFields() {
		Nerc selectedNerc = this.cmbNerc.getValue();
		String maxYearsInput = this.txtYears.getText();
		String maxHoursInput = this.txtHours.getText();
		
		if(selectedNerc!=null && !maxYearsInput.isBlank() && !maxHoursInput.isBlank()) {
			this.btnWorstCase.setDisable(false);
		}else {
			this.btnWorstCase.setDisable(true);
		}
		
	}


	@FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert cmbNerc != null : "fx:id=\"cmbNerc\" was not injected: check your FXML file 'Scene.fxml'.";
        assert txtYears != null : "fx:id=\"txtYears\" was not injected: check your FXML file 'Scene.fxml'.";
        assert txtHours != null : "fx:id=\"txtHours\" was not injected: check your FXML file 'Scene.fxml'.";
        assert txtResult != null : "fx:id=\"txtResult\" was not injected: check your FXML file 'Scene.fxml'.";
        assert btnWorstCase != null : "fx:id=\"btnWorstCase\" was not injected: check your FXML file 'Scene.fxml'.";
        // Utilizzare questo font per incolonnare correttamente i dati;
        txtResult.setStyle("-fx-font-family: monospace");
    }
    
  
    
    public void setModel(Model model) {
    	this.model = model;
    	this.cmbNerc.getItems().addAll(this.model.getNercList());
    }
}
