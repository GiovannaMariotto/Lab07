package it.polito.tdp.poweroutages.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import it.polito.tdp.poweroutages.model.Event;
import it.polito.tdp.poweroutages.model.Nerc;

public class PowerOutageDAO {
	
	private	List<Event> eventi;
	
	public List<Event> getEventi() {
		return this.eventi;
	}
	
	public void setEventi(List<Event> e){
		this.eventi=e;
	}
	
	
	public List<Nerc> getNercList() {

		String sql = "SELECT id, value FROM nerc";
		List<Nerc> nercList = new ArrayList<>();

		try {
			Connection conn = ConnectDB.getConnection();
			PreparedStatement st = conn.prepareStatement(sql);
			ResultSet res = st.executeQuery();

			while (res.next()) {
				Nerc n = new Nerc(res.getInt("id"), res.getString("value"));
				nercList.add(n);
			}

			conn.close();

		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

		return nercList;
	}
	
	public List<Event> getAllEvents(Nerc nerc) {
		final String sql ="SELECT id, nerc_id, customers_affected, date_event_began, date_event_finished "
				+ "FROM PowerOutages "
				+ "WHERE nerc_id =? "
				+ "ORDER BY date_event_began ASC, date_event_finished ASC";
		List<Event> eventlist =  new ArrayList();
		Connection conn = ConnectDB.getConnection();
		try {
			
			PreparedStatement st = conn.prepareStatement(sql);
			st.setInt(1, nerc.getId());
			ResultSet rs = st.executeQuery();
			
			while(rs.next()) {
				LocalDateTime l1 = rs.getTimestamp("date_event_began").toLocalDateTime();
				LocalDateTime l2 = rs.getTimestamp("date_event_finished").toLocalDateTime();
				int customersAffected = rs.getInt("customers_affected");
				int eventId = rs.getInt("id");
				Event evento = new Event(l1,l2,customersAffected,nerc,eventId);
				eventlist.add(evento);
			}
		
			
			nerc.setEventi(eventlist);
			st.close();
			rs.close();
			conn.close();
			
		
		}catch(SQLException e) {
			throw new RuntimeException(e);
		}
		
		if(eventlist==null) {
			System.out.println("ERROR: getAllEvents(nerc) Method");
			return null;
		}
		return eventlist;
		
	}
	
	
	
}
