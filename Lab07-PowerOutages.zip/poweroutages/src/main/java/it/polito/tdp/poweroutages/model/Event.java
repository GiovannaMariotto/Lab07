package it.polito.tdp.poweroutages.model;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Period;

public class Event {

	private LocalDateTime data_inizio;
	private LocalDateTime data_fine;
	private double numeroOre;
	private int numeroPersoneCoinvolte;
	private Nerc nerc;
	private int id;
	private int nAnni;
	
	
	public Nerc getNerc() {
		return nerc;
	}

	public void setNerc(Nerc nerc) {
		this.nerc = nerc;
	}


	
	public Event(LocalDateTime data_inizio, LocalDateTime data_fine,  int numeroPersoneCoinvolte,Nerc nerc, int id) {
		super();
		this.data_inizio = data_inizio;
		this.data_fine = data_fine;
		Duration duration = Duration.between(data_inizio, data_fine);
		this.numeroOre = (int) duration.toHours();
		Period periodo = Period.between(data_inizio.toLocalDate(), data_fine.toLocalDate());
		nAnni = periodo.getYears();
		this.numeroPersoneCoinvolte = numeroPersoneCoinvolte;
		this.nerc = nerc;
		this.id = id;
	
	}


	public int getnAnni() {
		return nAnni;
	}

	public void setnAnni(int nAnni) {
		this.nAnni = nAnni;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		result = prime * result + ((nerc == null) ? 0 : nerc.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Event other = (Event) obj;
		if (id != other.id)
			return false;
		if (nerc == null) {
			if (other.nerc != null)
				return false;
		} else if (!nerc.equals(other.nerc))
			return false;
		return true;
	}

	public LocalDateTime getData_inizio() {
		return data_inizio;
	}

	public void setData_inizio(LocalDateTime data_inizio) {
		this.data_inizio = data_inizio;
	}

	public LocalDateTime getData_fine() {
		return data_fine;
	}

	public void setData_fine(LocalDateTime data_fine) {
		this.data_fine = data_fine;
	}

	public double getNumeroOre() {
		return numeroOre;
	}

	public void setNumeroOre(double numeroOre) {
		this.numeroOre = numeroOre;
	}

	public int getNumeroPersoneCoinvolte() {
		return numeroPersoneCoinvolte;
	}

	public void setNumeroPersoneCoinvolte(int numeroPersoneCoinvolte) {
		this.numeroPersoneCoinvolte = numeroPersoneCoinvolte;
	}

	@Override
	public String toString() {
		return this.id+" "+ this.getNerc().getValue()+" " +this.getNumeroOre()+"  "+this.getNumeroPersoneCoinvolte()+"  "+ "("+ this.getData_fine() +"-"+this.getData_inizio()+ ")" ;
	}
	
	
	
	
}
