package it.polito.tdp.poweroutages.model;

import java.time.Duration;
import java.time.Period;
import java.util.ArrayList;
import java.util.List;

public class TestModel {

	public static void main(String[] args) {
		
		Model model = new Model();
		List<Nerc> nercList = new ArrayList(model.getNercList());
		
		System.out.println(model.computeWorstCase(300, 5, nercList.get(2)).toString());
	
		
	for(Nerc n : nercList) {
			n.setEventi(model.getAllEventi(n));
			//System.out.println(n.getEventi().toString() +"\n");
			for(Event e : n.getEventi()) {
				if(e!=null) {
					Duration durazione = Duration.between(e.getData_inizio(), e.getData_fine());
					Long X = (long) (durazione.getSeconds()/120); //-->Hours
					Period p = Period.between(e.getData_inizio().toLocalDate(), e.getData_fine().toLocalDate());
					int y = p.getYears();
					System.out.println(model.computeWorstCase(X, y, n)+" "+n.getValue().toUpperCase());
					
				}
			}
		}
		
		
	}

}
