package it.polito.tdp.poweroutages.DAO;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

import it.polito.tdp.poweroutages.model.Event;
import it.polito.tdp.poweroutages.model.Model;
import it.polito.tdp.poweroutages.model.Nerc;

public class TestPowerOutagesDAO {

	public static void main(String[] args) {
		
		try {
			Connection connection = ConnectDB.getConnection();
			connection.close();
			System.out.println("Connection Test PASSED");
			
		} catch (Exception e) {
			System.err.println("Test FAILED");
		}
		PowerOutageDAO dao = new PowerOutageDAO() ;
		List<Nerc> nercList = new ArrayList(dao.getNercList());
		Model model = new Model();
			for(Nerc n : nercList) {
				n.setEventi(model.getAllEventi(n));
				for(Event e : n.getEventi()) {
					if(e!=null) {
						//System.out.println(""+e.getNerc().getValue()+" "+e.getNumeroOre()+" "+e.getNumeroPersoneCoinvolte()+" "+e.getId());
						if(!model.computeWorstCase(1000, 6, n).isEmpty()) {
							System.out.println(model.computeWorstCase(1000, 6, n).toString());
						}
					}
				}
			}
			

	}

}
