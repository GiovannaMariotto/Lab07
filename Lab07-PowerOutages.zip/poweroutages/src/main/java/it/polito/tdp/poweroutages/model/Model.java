package it.polito.tdp.poweroutages.model;

import java.time.Duration;
import java.time.LocalDateTime;
import java.time.Period;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import it.polito.tdp.poweroutages.DAO.PowerOutageDAO;

public class Model {
	
	PowerOutageDAO podao;
	Map<Nerc,List<Event>> powerOutagesByNerc;
	List<Nerc> nercList;
	
	
	/**
	 * From the NercValue, can find an Obj Nerc
	 * @param nercValue
	 * @return Nerc is found ( with its list of event ); else: null
	 */
	public Nerc getNerc(String nercValue) {
		Nerc c =null;
		for(Nerc n: nercList) {
			if(n.getValue().equals(nercValue)) {
				 c = n;
				 if(!powerOutagesByNerc.containsKey(c)) {
					List<Event> nercEventList = this.getAllEventi(c);
					 powerOutagesByNerc.put(c, nercEventList);
				 }
			}	
		}
		if(c==null) {
			System.out.println("ERROR: NERC NOT FOUND");
			return null;
		}
		return c;
		
	}
	
	
	public Model() {
		podao = new PowerOutageDAO();
		powerOutagesByNerc = new HashMap<Nerc,List<Event>>();
		nercList=new ArrayList(podao.getNercList());
	}
	
	public List<Nerc> getNercList() {
		return nercList;
	}
	
	public List<Event> getAllEventi(Nerc nerc){
		if(!powerOutagesByNerc.containsKey(nerc)) {
			List<Event> eventl = this.podao.getAllEvents(nerc);
			powerOutagesByNerc.put(nerc, eventl);
		}
		return powerOutagesByNerc.get(nerc);
	}
	
	/**
	 * Metodo per chimare la ricorsione
	 * @param maxOre
	 * @param maxAnni
	 * @param nerc
	 * @return parziale
	 */
	public List<Event> computeWorstCase(double maxOre, int maxAnni, Nerc nerc){
		List<Event> eventl;
		/*First thing: populate the identity Map if it's not populated yet*/
		if(!powerOutagesByNerc.containsKey(nerc)) {
			 eventl = new ArrayList(this.podao.getAllEvents(nerc));
			if(!eventl.isEmpty()) {
				nerc.setEventi(eventl);
				powerOutagesByNerc.put(nerc, eventl);
			}else {
				System.out.println("ERROR on Method computeWorstCase() ");
			}
		}
		List<Event> powerOutagesOfNerc = this.getAllEventi(nerc);
		
		if(powerOutagesOfNerc.isEmpty()) { 
			System.out.println("powerOutagesOfNerc is null");
			return powerOutagesOfNerc;
		}
		List<Event> worstCase = new ArrayList();
		List<Event> parziale = new ArrayList();
		Period maxPeriod = Period.ofYears(maxAnni);//Years -->Period
		Duration maxDuration = Duration.ofHours((long) maxOre);//Ore-->Duration
		
		this.recursiveWorstCaseComputation(parziale,powerOutagesOfNerc,0,worstCase,maxPeriod,maxDuration);
		
	
		
		return worstCase;
		
	}
	
	/**
	 * Metodo recorsivo
	 * @param parziale
	 * @param allPowerOutages
	 * @param offset
	 * @param worstCase
	 * @param maxPeriod
	 * @param maxDuration
	 */
	private void recursiveWorstCaseComputation(List<Event> parziale, List<Event> allPowerOutages, int offset,
			List<Event> worstCase, Period maxPeriod, Duration maxDuration) {
		int size = allPowerOutages.size();
		if(offset==size) {
			//examinate the last entry
			//either parziale is a solution or parziale without the last element is a solution
			if(this.respectConstrains(parziale,maxPeriod,maxDuration)) {
				if(totCostumersAffected(parziale)>totCostumersAffected(worstCase)) {
					worstCase.clear(); //if it's worst, then repopulate worstCase List
					worstCase.addAll(parziale);
				}
			} else {
				List<Event> temp = parziale.subList(0, parziale.size()-1);
				if(totCostumersAffected(temp)>totCostumersAffected(worstCase)  ) {
					worstCase.clear();
					worstCase.addAll(temp);
				}
			}
			return;
		}
		
		if(!this.respectConstrains(parziale,maxPeriod,maxDuration)) {
			return;
		}
		
		for(int i=offset;i<size;i++) {
			Event po = allPowerOutages.get(i);
			parziale.add(po);
			recursiveWorstCaseComputation(parziale, allPowerOutages, i+1, worstCase, maxPeriod, maxDuration);
			//BackTracking
			int lastIndex=parziale.size()-1;
			parziale.remove(lastIndex);
			
			
		}
		
		
		
	}

	/**
	 * 
	 * @param parziale
	 * @param maxPeriod
	 * @param maxDuration
	 * @return true if it doesn't exceed the Duration and the Period (false, otherwise )
	 */
	
	private boolean respectConstrains(List<Event> parziale, Period maxPeriod, Duration maxDuration) {
		
		return !exceed(parziale, maxPeriod) && !exceed(parziale, maxDuration);
	}
	
	/**
	 * Exceeds or not the maxDuration
	 * @param parziale
	 * @param maxDuration
	 * @return If exceeds the max Duration, return true. Else, return false
	 */

	private boolean exceed(List<Event> parziale, Duration maxDuration) {
		Duration duration = Duration.ofHours(0);
		for(Event e : parziale) {
			LocalDateTime begin = e.getData_inizio();
			LocalDateTime finish = e.getData_fine();
			Duration eventDuration = Duration.between(begin, finish);
			duration = duration.plus(eventDuration);
		}
		
		
		return duration.compareTo(maxDuration)>0;
	}

	
	/**
	 * Exceeds or not the maxPeriod
	 * @param parziale
	 * @param maxPeriod
	 * @return True if it exceeds the maxPeriod
	 */
	private boolean exceed(List<Event> parziale, Period maxPeriod) {
		if(parziale.isEmpty()) {
			return false;
		}
		Event oldest = parziale.get(0);
		Event recent = parziale.get(parziale.size()-1);
		LocalDateTime oldestDate = oldest.getData_inizio();
		LocalDateTime newestDate = recent.getData_fine();
		
		LocalDateTime maxOffset = oldestDate.plus(maxPeriod);
		
		return newestDate.isAfter(maxOffset);
	}

	
	/**
	 * Count the number of affected people in a list of PowerOutage events
	 * @param lista
	 * @return numero totale di persone coinvolte
	 */
	public int totCostumersAffected(List<Event> lista) {
		int count = 0;
		for(Event e : lista) {
			count+=e.getNumeroPersoneCoinvolte();
		}
		return count;
		
	}
	/**
	 * Count how many hours of PowerOutages in a list
	 * @param listaEventi
	 * @return How many hours of outbreak in total 
	 */
	public long totHoursAffected(List<Event> listaEventi) {
		 Duration duration = Duration.ofHours(0);
		 for(Event e : listaEventi) {
			 LocalDateTime begin = e.getData_inizio();
			 LocalDateTime fin = e.getData_fine();
			 Duration eventDuration = Duration.between(begin, fin);
			 duration = duration.plus(eventDuration);
		 }
		
		
		return duration.toHours();
	}

	
	
	
	
}
